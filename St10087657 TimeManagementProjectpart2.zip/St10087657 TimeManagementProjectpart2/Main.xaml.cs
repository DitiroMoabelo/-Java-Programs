﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace St10087657_TimeManagementProjectpart2
{
    /// <summary>
    /// Interaction logic for Main.xaml
    /// </summary>
    public partial class Main : Window
    {
        private List<Module> modules = new List<Module>();
        private DateTime startDate;
        private int numberOfWeeks;

        public Main()
        {
            InitializeComponent();
        }
        private void AddModuleButton_Click(object sender, RoutedEventArgs e)
        {
            // Validate and add a new module to the list
            if (int.TryParse(CreditsTextBox.Text, out int credits) &&
                int.TryParse(ClassHoursTextBox.Text, out int classHours))
            {
                var module = new Module
                {
                    Code = CodeTextBox.Text,
                    Name = NameTextBox.Text,
                    Credits = credits,
                    ClassHoursPerWeek = classHours
                };

                modules.Add(module);//(Miskovic, 2022)

                // Clear input fields
                CodeTextBox.Clear();
                NameTextBox.Clear();
                CreditsTextBox.Clear();
                ClassHoursTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Invalid input. Please check credits and class hours.");
            }
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            if (DateTime.TryParse(StartDateTextBox.Text, out startDate) &&
                int.TryParse(WeeksTextBox.Text, out numberOfWeeks))
            {
                // Calculate and display self-study hours using LINQ query
                var selfStudyHours = modules.Select(module =>
                    new
                    {
                        Module = module,
                        SelfStudyHoursPerWeek = (module.Credits * 10) / (numberOfWeeks - module.ClassHoursPerWeek)
                    });

                ModulesListView.ItemsSource = selfStudyHours;//(Chauhan, 2022)

                // Clear input fields
                StartDateTextBox.Clear();
                WeeksTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Invalid input. Please check start date and number of weeks.");
            }
        }


        private void RecordHoursButton_Click(object sender, RoutedEventArgs e)
        {
            if (DateTime.TryParse(DateTextBox.Text, out DateTime date) &&
                double.TryParse(HoursTextBox.Text, out double hours))
            {
                // Find the module corresponding to the selected date
                var selectedModule = ModulesListView.SelectedItem as dynamic;

                if (selectedModule != null)
                {
                    selectedModule.Module.RecordHours(date, hours);
                }

                // Clear input fields
                DateTextBox.Clear();
                HoursTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Invalid input. Please check date and hours.");
            }
        }

        private void ModulesListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void DateTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }

    public class Module
    {
        public string Code { get; set; }//(Misko, 2023)
        public string Name { get; set; }
        public int Credits { get; set; }
        public int ClassHoursPerWeek { get; set; }
        public List<(DateTime Date, double Hours)> HoursRecorded { get; set; } = new List<(DateTime Date, double Hours)>();

        public void RecordHours(DateTime date, double hours)
        {
            HoursRecorded.Add((date, hours));
        }


        public class User
        {
            public int Id { get; set; }
            public string Username { get; set; }
            public string PasswordHash { get; set; }
        }
        public double GetRemainingSelfStudyHours(DateTime startDate, int numberOfWeeks)
        {
            var currentWeek = (DateTime.Now - startDate).Days / 7;
            var totalClassHours = currentWeek * ClassHoursPerWeek;
            var totalRecordedHours = HoursRecorded
                .Where(record => (record.Date - startDate).Days / 7 == currentWeek)
                .Sum(record => record.Hours);

            // Calculate the remaining self-study hours by subtracting total class hours and total recorded hours
            var remainingSelfStudyHours = (Credits * 10) - (totalClassHours + totalRecordedHours);
            return remainingSelfStudyHours;
        }

    }
}

