﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Tweetinvi.Security;

namespace St10087657_TimeManagementProjectpart2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //register button
        private void button_Click(object sender, RoutedEventArgs e)
        {
            string username, password;

            username = Username.Text;
            password = Password.Text;
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\lab_services_student\\source\\repos\\St10087657 TimeManagementProjectpart2\\St10087657 TimeManagementProjectpart2\\user.mdf\";Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var sha1 = new SHA1CryptoServiceProvider();
                var bytePassword = Encoding.ASCII.GetBytes(password);
                var sha1data = sha1.ComputeHash(bytePassword);
                var hashedPassword = ASCIIEncoding.GetEncoding(0).GetString(sha1data);
                string query = $"Insert into [dbo].[User] (Username, PasswordHash) values ('{username}', '{hashedPassword}')";
                SqlCommand command = new SqlCommand(query, connection);
              
                command.ExecuteNonQuery();
                int count = Convert.ToInt32(command.ExecuteScalar());
                connection.Close();

                if (count > 0) 
                {
                    MessageBox.Show("User Successfully Registered");
                    Main main = new Main();
                    main.Show();
                    this.Close();

                }
                else
                {
                    MessageBox.Show("User Successfully Registered");
                }

            }
            }

        

        private void login_Click(object sender, RoutedEventArgs e)
        {
            login login = new login();
            login.Show();
            this.Close();
        }
    }
}
/*
 Bibliography
Chauhan, S., 2022. dotnettricks.com. [Online]
Available at: https://www.dotnettricks.com/learn/linq/sql-joins-with-csharp-linq
[Accessed 20 September 2023].
Misko, j., 2023. josipmisko.com. [Online]
Available at: https://josipmisko.com/posts/c-sharp-get-set-accessor
[Accessed 20 September 2023].
Miskovic, J., 2022. josipmisko.com. [Online]
Available at: https://josipmisko.com/posts/c-sharp-add-to-list-does-not-exist
[Accessed 20 September 2023].


 */