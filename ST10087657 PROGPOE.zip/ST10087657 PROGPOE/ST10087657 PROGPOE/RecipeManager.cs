﻿

using System;

using System.Collections.Generic;

namespace ST10087657RecipeApp
{
    // Class recipe store by using generic collections.
    class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }
        // Add ingredient 
        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }
        // add step 
        public void AddStep(string step)
        {
            Steps.Add(step);
        }
        // The app displays the list of recipes in alphabetical order.
        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe: " + Name);
            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in Ingredients)
            {
                Console.WriteLine("- " + ingredient.Quantity + " " + ingredient.Unit + " " + ingredient.Name + " (" + ingredient.Calories + " calories, " + ingredient.FoodGroup + ")");
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + Steps[i]);
            }
            Console.WriteLine();
        }

        // Scale the recipe 
        public void ScaleRecipe(double factor)
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                if (factor == 1)
                // Rescale recipe by 0.5
                {
                    ingredient.Quantity *= 0.5;
                }
                // Rescale recipe by 2
                else if (factor == 2)
                {
                    ingredient.Quantity *= 2;
                }
                // Rescale recipe by 3
                else if (factor == 3)
                {
                    ingredient.Quantity *= 3;
                }
                //
                else
                {
                    throw new ArgumentException("Invalid scaling factor. Scaling factor must be 1, 2, or 3.");
                }
            }
        }
        // Reset Quantity 
        public void ResetQuantities()
        {
            if (Ingredients.Count == 0)
            {
                throw new InvalidOperationException("Cannot reset quantities. The ingredients list is empty.");
            }

            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.OriginalQuantity;
            }
        }

        // Get Total Calories 
        public double GetTotalCalories()
        {
            double totalCalories = 0;
            foreach (Ingredient ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories * ingredient.Quantity;
            }
            return totalCalories;
        }
        //  The user is notified when the calories of a recipe exceed 300 by using a Delegate.
        public delegate void RecipeCaloriesExceededHandler(Recipe recipe);
       
        public event RecipeCaloriesExceededHandler RecipeCaloriesExceeded;
      
        public void CheckCalories()
        {
            if (GetTotalCalories() > 300)
            {
                RecipeCaloriesExceeded?.Invoke(this);
            }
        }
    }

    
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public double OriginalQuantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }

        public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            OriginalQuantity = quantity;
            Unit = unit;

            
            Calories = calories;
       
            FoodGroup = foodGroup;
        }
    }

   
    class RecipeManager
    {
        public List<Recipe> Recipes { get; set; }

        public RecipeManager()
        {
            Recipes = new List<Recipe>();
        }
        // Add recipe
        public void AddRecipe(Recipe recipe)
        {
            Recipes.Add(recipe);
        }
        // Display all the recipe 
        public void DisplayAllRecipes()
        {
            //The app displays the list of recipes in alphabetical order by using sort.
            Recipes.Sort((r1, r2) => r1.Name.CompareTo(r2.Name));
            Console.WriteLine("List of all recipes:");
            foreach (Recipe recipe in Recipes)
            {
                Console.WriteLine("- " + recipe.Name);
            }
            Console.WriteLine();
        }
        // search recipe by using the name
        public Recipe SearchRecipe(string name)
        {
            foreach (Recipe recipe in Recipes)
            {
                if (recipe.Name == name)
                {
                    return recipe;
                }
            }
            return null;
        }
    }
    
}
