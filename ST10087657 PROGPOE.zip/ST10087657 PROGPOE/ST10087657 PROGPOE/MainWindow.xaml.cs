﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using static System.Net.Mime.MediaTypeNames;
using ST10087657RecipeApp;
using System.ComponentModel;



namespace ST10087657RecipeApp
{

    public partial class MainWindow : Window
    {
        private RecipeManager recipeManager;
        private Recipe currentRecipe;
        public MainWindow()
        {
            InitializeComponent();
            recipeManager = new RecipeManager();
            
        }

        //(Beniwal, 2018)
        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text;

            if (string.IsNullOrWhiteSpace(recipeName))
            {
                MessageBox.Show("Please enter a recipe name.");
                return;
            }

            int numIngredients;
            if (!int.TryParse(NumIngredientsTextBox.Text, out numIngredients))
            {
                MessageBox.Show("Invalid input. Please enter a valid number of ingredients.");
                return;
            }

            Recipe recipe = new Recipe(recipeName);

            for (int i = 0; i < numIngredients; i++)
            {
                string ingredientName = PromptUserForInput("Enter the name of ingredient " + (i + 1) + ":");
                if (string.IsNullOrWhiteSpace(ingredientName))
                {
                    MessageBox.Show("Invalid input.Enter a valid ingredient name for ingredient " + (i + 1) + ".");
                    return;
                }
                //(Seggemu, 2022)
                double quantity;
                if (!double.TryParse(PromptUserForInput("Enter the quantity for ingredient " + (i + 1) + ":"), out quantity))
                {
                    MessageBox.Show("Invalid input.Enter a valid quantity for ingredient " + (i + 1) + ".");
                    return;
                }

                string unit = PromptUserForInput("Enter the unit for ingredient " + (i + 1) + ":");
                double calories;
                if (!double.TryParse(PromptUserForInput("Enter the calories for ingredient " + (i + 1) + ":"), out calories))
                {
                    MessageBox.Show("Invalid input. Please enter a valid number of calories for ingredient #" + (i + 1) + ".");
                    return;
                }
                string foodGroup = PromptUserForInput("Enter the food group of the ingredient" + (i + 1) + ":");

                Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, calories, foodGroup);
                recipe.AddIngredient(ingredient);
            }

            recipeManager.AddRecipe(recipe);
            //(Naidamast, 2016)
            MessageBox.Show("Recipe successfully added!");
        }

        private void AddStepButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe == null)
            {
                MessageBox.Show("Please add a recipe first.");
                return;
            }

            string step = StepTextBox.Text;

            if (string.IsNullOrWhiteSpace(step))
            {
                MessageBox.Show("Please enter a step.");
                return;
            }

            currentRecipe.AddStep(step);
            MessageBox.Show("Step added successfully!");
        }

        private void ShowRecipeStepsAndCalories(Recipe recipe)
        {
            string recipeDetails = "Recipe: " + recipe.Name + "\n";
            recipeDetails += "Ingredients:\n";

            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                recipeDetails += "- " + ingredient + "\n";
            }

            recipeDetails += "Steps:\n";

            
            foreach (string step in recipe.Steps)
            {
                recipeDetails += step + "\n";
                
            }

            recipeDetails += "Calories: " + recipe.GetTotalCalories() + "\n";

            if (recipe.GetTotalCalories() > 300)
            {
                recipeDetails += "Warning: This recipe exceeds 300 calories!\n";
            }

            MessageBox.Show(recipeDetails);
        }


        private void DisplayRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeList = "List of all saved recipes:\n";

            foreach (Recipe recipe in recipeManager.Recipes)
            {
                recipeList += "- " + recipe.Name + "\n";
            }

            MessageBox.Show(recipeList);
        }

        private void SearchRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = SearchRecipeTextBox.Text;

            if (string.IsNullOrWhiteSpace(recipeName))
            {
                MessageBox.Show("Please enter a recipe name.");
                return;
            }

            Recipe recipe = recipeManager.SearchRecipe(recipeName);

            if (recipe == null)
            {
                MessageBox.Show("Recipe not found!");
            }
            else
            {
                ShowRecipeStepsAndCalories(recipe);
            }
        }
        
        



        private void ScaleRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = SearchRecipeTextBox.Text;

            if (string.IsNullOrWhiteSpace(recipeName))
            {
                MessageBox.Show("Please enter a recipe name.");
                return;
            }

            Recipe recipe = recipeManager.SearchRecipe(recipeName);

            if (recipe == null)
            {
                MessageBox.Show("Recipe not found!");
                return;
            }

            double factor;
            if (!double.TryParse(ScaleFactorTextBox.Text, out factor) || factor < 1 || factor > 3)
            {
                MessageBox.Show("Invalid input. Please enter a valid scaling factor (1, 2, or 3).");
                return;
            }

            try
            {
                recipe.ScaleRecipe(factor);
                MessageBox.Show("Recipe scaled successfully!");
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void ResetQuantitiesButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = SearchRecipeTextBox.Text;

            if (string.IsNullOrWhiteSpace(recipeName))
            {
                MessageBox.Show("Please enter a recipe name.");
                return;
            }

            Recipe recipe = recipeManager.SearchRecipe(recipeName);

            if (recipe == null)
            {
                MessageBox.Show("Recipe not found!");
                return;
            }

            recipe.ResetQuantities();
            MessageBox.Show("Quantities reset successfully!");
        }

        private void ClearDataButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = SearchRecipeTextBox.Text;

            if (string.IsNullOrWhiteSpace(recipeName))
            {
                MessageBox.Show("Please enter a recipe name.");
                return;
            }

            Recipe recipe = recipeManager.SearchRecipe(recipeName);

            if (recipe == null)
            {
                MessageBox.Show("Recipe not found!");
                return;
            }

            recipe.Ingredients.Clear();
            recipe.Steps.Clear();
            MessageBox.Show("All data cleared!");
        }

        private string PromptUserForInput(string message)
        {
            MessageBoxResult result = MessageBox.Show(message, "User Input", MessageBoxButton.OKCancel, MessageBoxImage.Question);

            if (result == MessageBoxResult.OK)
            {
                InputDialog inputDialog = new InputDialog(); // Create a custom input dialog
                bool? dialogResult = inputDialog.ShowDialog();

                if (dialogResult == true)
                {
                    return inputDialog.InputText;
                }
            }

            return string.Empty;
        }
    }
    }
/*
 * Bibliography
Beniwal, D., 2018. c-sharpcorner.com. [Online] 
Available at: https://www.c-sharpcorner.com/UploadFile/dbeniwal321/button-control-in-wpf/
[Accessed 04 July 2023].
Naidamast, S., 2016. devm.io. [Online] 
Available at: https://devm.io/programming/smple-way-make-custom-wpf-message-box-129558
[Accessed 04 July 2023].
Seggemu, A., 2022. akarshseggemu.medium.com. [Online] 
Available at: https://akarshseggemu.medium.com/how-to-parse-int-and-double-value-in-unity-c-5c2518c735be
[Accessed 04 July 2023].


 */