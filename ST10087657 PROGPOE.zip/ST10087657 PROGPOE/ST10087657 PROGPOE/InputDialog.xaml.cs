﻿using System.Windows;
using System.Windows.Controls;

namespace ST10087657RecipeApp
{
    public partial class InputDialog : Window
    {
        private TextBox inputTextBox;

        public string InputText { get; private set; }

        public InputDialog()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            Title = "User Input";

            StackPanel mainPanel = new StackPanel();
            Content = mainPanel;

            Label messageLabel = new Label();
            messageLabel.Content = "Enter input:";
            mainPanel.Children.Add(messageLabel);

            inputTextBox = new TextBox();
            mainPanel.Children.Add(inputTextBox);

            StackPanel buttonPanel = new StackPanel();
            mainPanel.Children.Add(buttonPanel);

            Button okButton = new Button();
            okButton.Content = "OK";
            okButton.Click += OkButton_Click;
            buttonPanel.Children.Add(okButton);

            Button cancelButton = new Button();
            cancelButton.Content = "Cancel";
            cancelButton.Click += CancelButton_Click;
            buttonPanel.Children.Add(cancelButton);
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            InputText = inputTextBox.Text;
            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
