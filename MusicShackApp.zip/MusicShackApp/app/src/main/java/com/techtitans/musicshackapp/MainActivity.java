package com.techtitans.musicshackapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText titleEditText, albumEditText, yearEditText, mediaTypeEditText, artistEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize EditText fields
        titleEditText = findViewById(R.id.titleEditText);
        albumEditText = findViewById(R.id.albumEditText);
        yearEditText = findViewById(R.id.yearEditText);
        mediaTypeEditText = findViewById(R.id.mediaTypeEditText);
        artistEditText = findViewById(R.id.artistEditText);

        Button submitButton = findViewById(R.id.button);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get input values
                String title = titleEditText.getText().toString();
                String album = albumEditText.getText().toString();
                String year = yearEditText.getText().toString();
                String mediaType = mediaTypeEditText.getText().toString();
                String artist = artistEditText.getText().toString();

                // Validate input
                if (title.isEmpty() || album.isEmpty() || year.isEmpty() || mediaType.isEmpty() || artist.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Save the data or perform any other action
                saveMusicItem(title, album, year, mediaType, artist);

                // Clear input fields
                clearInputFields();
            }
        });

        // Implement search functionality here
        // You can add an onClickListener to the searchIcon and handle the search logic
    }

    private void saveMusicItem(String title, String album, String year, String mediaType, String artist) {
        // This method should save the music item to a database or perform any other necessary action
        // For demonstration purposes, I'm just displaying a toast message
        String message = "Music item added: \nTitle: " + title + "\nAlbum: " + album + "\nYear: " + year + "\nMedia Type: " + mediaType + "\nArtist: " + artist;
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void clearInputFields() {
        // Clear all input fields after submission
        titleEditText.setText("");
        albumEditText.setText("");
        yearEditText.setText("");
        mediaTypeEditText.setText("");
        artistEditText.setText("");
    }
}
